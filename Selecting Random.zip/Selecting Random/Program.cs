using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Selecting_Random
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Press '1' for restaurants. Press '2' for Out and About. Press '3' for $45 and under. Press '4' for $45 and above. Press '5' for at Home.");
            double c = Convert.ToDouble(Console.ReadLine());
            if (c == 1)
            {
                Restaurant();
            }
            if (c == 2)
            {
                OutAndAbout();
            }
            if (c == 3)
            {
                SpendUnder45();
            }
            if (c == 4)
            {
                SpendOver45();
            }
            if (c == 5)
            {
                AtHome();
            }
            Console.ReadKey();
        }
        static public void Restaurant()
        {
            string c = "0";
            List<String> restaurants = new List<String>();
            restaurants.AddRange(new String[]
                { "Chillies", "Apple-Bees", "Denny's", "Golden Corral", "Hibachi", "Old Chicago", "Zocalo", "Red Robins", "Hwy 55", "Wendy's", "Rita's", "Taco Bell", "Cold Stone", "Jimmy Johns", "McDonalds", "Baked Pizza Co", "Burger King", "Panda Express", "Subway" });
            Random random = new Random();
            Console.WriteLine("Click 'Enter' for random Restaurant choice. Click 'x' then 'Enter' to exit or Click '1', '2', '3', '4', or '5' for the previous options.");
            do
            {
                c = Convert.ToString(Console.ReadLine());
                { 
                    if (c == "1")
                    {
                        Restaurant();
                    }
                    if (c == "2")
                    {
                        OutAndAbout();
                    }
                    if (c == "3")
                    {
                        SpendUnder45();
                    }
                    if (c == "4")
                    {
                        SpendOver45();
                    }
                    if (c == "5")
                    {
                        AtHome();
                    }
                    if (c == "x")
                    {
                        break;
                    }
                    else
                    {
                        Console.WriteLine(restaurants[random.Next(0, restaurants.Count)]);
                    }
                }
            }
            while (c != "x");
        }

        static public void OutAndAbout()
        {
            string c = "0";
            List<String> outdoor = new List<String>();
            outdoor.AddRange(new String[]
                { "Kayaking", "PokemonGo", "Picnic", "Beach", "Take Cujo to Park", "Outdoor Sport"});
            Random random = new Random();
            Console.WriteLine("Click 'Enter' for random Out Door Activity choice. Click 'x' then 'Enter' to exit or Click '1', '2', '3', '4', or '5' for the previous options.");
            do
            {
                c = Convert.ToString(Console.ReadLine());
                {
                    if (c == "1")
                    {
                        Restaurant();
                    }
                    if (c == "2")
                    {
                        OutAndAbout();
                    }
                    if (c == "3")
                    {
                        SpendUnder45();
                    }
                    if (c == "4")
                    {
                        SpendOver45();
                    }
                    if (c == "5")
                    {
                        AtHome();
                    }
                    if (c == "x")
                    {
                        break;
                    }
                    else
                    {
                        Console.WriteLine(outdoor[random.Next(0, outdoor.Count)]);
                    }
                }
            }
            while (c != "x");
        }

        static public void SpendUnder45()
        {
            string c = "0";
            List<String> under = new List<String>();
            under.AddRange(new String[]
                { "Bowling", "Kayaking", "Marco Chooses Movie", "Bella Chooses Movie", "Beach Jar Project", "Aquarium", "Mac Daddy's Arcade", "Trampolin Park"});
            Random random = new Random();
            Console.WriteLine("Click 'Enter' for random Spend Under $45 choice. Click 'x' then 'Enter' to exit or Click '1', '2', '3', '4', or '5' for the previous options.");
            do
            {
                c = Convert.ToString(Console.ReadLine());
                {
                    if (c == "1")
                    {
                        Restaurant();
                    }
                    if (c == "2")
                    {
                        OutAndAbout();
                    }
                    if (c == "3")
                    {
                        SpendUnder45();
                    }
                    if (c == "4")
                    {
                        SpendOver45();
                    }
                    if (c == "5")
                    {
                        AtHome();
                    }
                    if (c == "x")
                    {
                        break;
                    }
                    else
                    {
                        Console.WriteLine(under[random.Next(0, under.Count)]);
                    }
                }
            }
            while (c != "x");
        }

        static public void SpendOver45()
        {
            string c = "0";
            List<String> over = new List<String>();
            over.AddRange(new String[]
                { "Comedy Show or Concert", "Paintball", "Pottery", "Leggo", "Nice Dinner", "Bush Gardens", "Mac Daddy's", "Tactical Laser Tag"});
            Random random = new Random();
            Console.WriteLine("Click 'Enter' for random Spend Over $45 choice. Click 'x' then 'Enter' to exit or Click '1', '2', '3', '4', or '5' for the previous options.");
            do
            {
                c = Convert.ToString(Console.ReadLine());
                {
                    if (c == "1")
                    {
                        Restaurant();
                    }
                    if (c == "2")
                    {
                        OutAndAbout();
                    }
                    if (c == "3")
                    {
                        SpendUnder45();
                    }
                    if (c == "4")
                    {
                        SpendOver45();
                    }
                    if (c == "5")
                    {
                        AtHome();
                    }
                    if (c == "x")
                    {
                        break;
                    }
                    else
                    {
                        Console.WriteLine(over[random.Next(0, over.Count)]);
                    }
                }
            }
            while (c != "x");
        }

        static public void AtHome()
        {
            string c = "0";
            List<String> home = new List<String>();
            home.AddRange(new String[]
                { "Video Games", "Massages", "Marco Picks Movie", "Puzzles", "Bubble Bath", "Board Games", "Binge Watch Tv Show", "Build a Fort", "Bella Picks Movie" });
            Random random = new Random();
            Console.WriteLine("Click 'Enter' for random Stay At Home Activity choice. Click 'x' then 'Enter' to exit or Click '1', '2', '3', '4', or '5' for the previous options.");
            do
            {
                c = Convert.ToString(Console.ReadLine());
                {
                    if (c == "1")
                    {
                        Restaurant();
                    }
                    if (c == "2")
                    {
                        OutAndAbout();
                    }
                    if (c == "3")
                    {
                        SpendUnder45();
                    }
                    if (c == "4")
                    {
                        SpendOver45();
                    }
                    if (c == "5")
                    {
                        AtHome();
                    }
                    if (c == "x")
                    {
                        break;
                    }
                    else
                    {
                        Console.WriteLine(home[random.Next(0, home.Count)]);
                    }
                }
            }
            while (c != "x");
        }
    }
}
